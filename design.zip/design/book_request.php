<?php
session_start()
?>

<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>Member</title>
	<link href="https://fonts.googleapis.com/css?family=Oswald" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css" media="all" />
	<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
</head>

<body>
	
	<div class="header bg-light" style="height: 128px;">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
				<div class="col-md-2 logo">
						<img src="image/logo.png" alt="university logo" />
					</div>
					<div class="col-md-2"></div>
					<div class="col-md-8 u-text">
						<h1>Education is the Backbone of a Nation</h1>
					</div>
					
					<nav class="navbar navbar-light bg-dark bg-lg">
						  <form class="form-inline ">
							<input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search" style="margin-left: 1010px;">
							<button class="btn btn-outline-light my-2 my-sm-0" type="submit">Search</button>
							
						  </form>
						  <h3 style="margin-top: -40px; font-family: 'Oswald', sans-serif;font-weight:400;margin-left: 480px;color: #fff;">Library Management System,PUST</h3>
					</nav>
					</br>
<table border='1px' align='center'>
			<tr>
				<th>Book Name</th>
				<th>Author</th>
				<th>Request user</th>
				<th>Aprrove</th>
				<th>Cancel</th>
			</tr>
<?php
      
	  include "conn.php";
		   
	 
                   $sql = "SELECT * FROM borrow,subject WHERE  borrow.code =subject.code AND borrow.req=1 AND borrow.status=0";
				   
                	$records = $con->query($sql);
					
					while($rows = $records->fetch_assoc())
                         {  
					        $code = $rows['code'];
							  echo "<tr>"; 
							  echo "<td>" . $rows['name'] . "</td>";
							    echo "<td>" . $rows['author'] . "</td>";
								 echo "<td>" . $rows['user'] . "</td>";
								  $user = $rows['user'];
								echo "<td>". "<a href='bookapp.php?usr=$user & code=$code'>Approve</a>" ."</td>";
								echo "<td>". "<a href='delete_book_req.php?usr=$user & code=$code'>Cancel</a>" ."</td>";
							  echo "</tr>";
						  }		
						

?>

</table>
</body>

</html>