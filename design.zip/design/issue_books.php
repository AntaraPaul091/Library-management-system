<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
</head>
<body>
	
</body>
</html>

<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>registration form</title>
	<link href="https://fonts.googleapis.com/css?family=Oswald" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css" media="all" />
	<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
</head>
<body>
	
	
	
	<div class="header bg-light" style="height: 128px;">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
				<div class="col-md-2 logo">
						<img src="image/logo.png" alt="university logo" />
					</div>
					<div class="col-md-2"></div>
					<div class="col-md-8 u-text">
						<h1>Education is the Backbone of a Nation</h1>
					</div>
					
					<nav class="navbar navbar-light bg-dark bg-lg">
						  <form class="form-inline ">
							<input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search" style="margin-left: 1010px;">
							<button class="btn btn-outline-light my-2 my-sm-0" type="submit">Search</button>
							
						  </form>
						  <h3 style="margin-top: -40px; font-family: 'Oswald', sans-serif;font-weight:400;margin-left: 480px;color: #fff;">Library Management System,PUST</h3>
					</nav>
					
					
					<form name="form1" action="" method="post">
					<table>
					<tr>
					<td>
					<select class="form-control selectpicker">
					<?php>
					$res=mysqli_query($link,"select enrollment from registration");
					while($row=mysqli_fetch_array($res)){
						
						echo"<option>"
						echo $row ["enrollmaent"];
						echo"</option>"
					}
					?>
					</select>
					</td>
					</tr>
					
				<tr>
					<td>
						<input type="submit" value="search" name="submit" class="form-control btn btn-default" style="margin-top:5px;">
					</td>
				</tr>
					</table>
					</form>
					
					<?php
					if (isset($POST["submit"])){
						
						?>
						
					<table class="table table-bordered">
						<tr>
							<td>
								<input type="text" class="form-control" placeholder="enrollmentno" name="enrollment" disabled> 
							</td>
						</tr>
						
						
						<tr>
							<td>
								<input type="text" class="form-control" placeholder="studentname" name="studentname" disabled> 
							</td>
						</tr>
						
						
						<tr>
							<td>
								<input type="text" class="form-control" placeholder="semester" name="semester" disabled> 
							</td>
						</tr>
						
						<tr>
							<td>
								<input type="text" class="form-control" placeholder="contactno" name="contactno" disabled> 
							</td>
						</tr>
						
						<tr>
							<td>
								<input type="text" class="form-control" placeholder="email" name="email" disabled> 
							</td>
						</tr>
						<tr>
							<td>
							<select name="bookname" class="form-control selectpicker" >
								<?php
								$res=mysqli_query($link,"select booksname from add_books");
								while($row=mysqli_fetch_array($res))
								{
									echo"<option >";
										
									echo $row["books_name"];
									echo"</option>";
									
									
								}
								?>
								<option >
								
								
								</option>
							
							</select>
							
							</td>
						
						</tr>
					</table>
								
								<? php
					}
					?>
					</div>
				</div>
			</div>
		</div>
</body>
</html>