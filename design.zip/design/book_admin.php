
<?php
session_start();
?>
 
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>Book Admin</title>
	<link href="https://fonts.googleapis.com/css?family=Oswald" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css" media="all" />
	<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
	<link href="style.css" rel="stylesheet" type="text/css"/>
	
	<style type="text/css"> 
	
	    body{
			margin:0px;
			border:0px;
			font-family: 'Roboto', sans-serif;
		} 
		
		.sidebar{
			    width: 291px;
				height: 331px;
				float: left;
		}
		
		.sidebar ul{
			list-style:none;
			margin:0;
			padding:0;
		}
		
		.sidebar ul li{
			padding:15px;
			position:relative;
			width:250px;
			vertical-align:middle;
			background:#34495E;
			border-top:1px solid #BDC3C7;
			cursor:pointer;
			
		}
		
		.sidebar ul ul{
			transition: all 0.3s;
			opacity:0;
			position:absolute;
			border-left: 5px solid #303035;
			visibility:hidden;
			left:100%;
			top:-2%;
		}
		
		.sidebar ul li:hover > ul{
			opacity: 1;
			visibility:visible;
		}
		.sidebar ul li a{
			color:#fff;
			text-decoration:none;
		}
		
		.sidebar > ul > li{
			border-right: 5px solid #303035;
		}
	
	   
	   span{
		   margin-right:15px;
	   }
	   
	
	</style>
</head>
<body>
	
	
	<div class="header bg-light" style="height: 128px;">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
				<div class="col-md-2 logo">
						<img src="image/logo.png" alt="university logo" />
					</div>
					<div class="col-md-2"></div>
					<div class="col-md-8 u-text">
						<h1>Education is the Backbone of a Nation</h1>
					</div>
					
				<nav class="navbar navbar-light bg-dark bg-lg" style="height: 59px;">
						  
						  <h3 style="margin-top: -5px; font-family: 'Oswald', sans-serif;font-weight:400;margin-left: 480px;color: #fff;">Library Management System,PUST</h3>
					</nav> 
					
					
					

<div class="whole">

<div class="sidebar">
<ul>

<li><a href="show_book.php">Book list</a></li>
<li><a href="book_request.php">Show book request</a></li>
<li><a href="return_book_request.php">Show Return book request</a></li>
<li><a href="update_book.php">Update book</a></li>
<li><a href="update_member.php">Update Member</a></li>
<li><a href="add_books.php">Add book</a></li>
<li><a href="member.php">Show All Member</a></li>
<li><a href="logout.php">Log out</a></li>
</ul>
</div>




</div>

</body>
</html>