<?php
session_start()
?>

<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>Log In Form</title>
	<link href="https://fonts.googleapis.com/css?family=Oswald" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css" media="all" />
	<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
</head>
<body>
	
	
	
	<div class="header bg-light" style="height: 128px;">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="col-md-2 logo">
						<img src="image/logo.png" alt="university logo" />
					</div>
					<div class="col-md-2"></div>
					<div class="col-md-8 u-text">
						<h1>Education is the Backbone of a Nation</h1>
					</div>
					
					<nav class="navbar navbar-light bg-dark bg-lg">
						  <form class="form-inline ">
							<input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search" style="margin-left: 1010px;">
							<button class="btn btn-outline-light my-2 my-sm-0" type="submit">Search</button>
							
						  </form>
						  <h3 style="margin-top: -40px; font-family: 'Oswald', sans-serif;font-weight:400;margin-left: 480px;color: #fff;">Library Management System,PUST</h3>
					</nav>
					
	
	 <form action="" method="post">
	
	<div class="alll" style="background:#F8F9FA;    margin-top: -179px;
    width: 1343px;
    margin-left: -116px;height:735px;">
	
	<h2 style="        margin-top: 154px;
    margin-left: 613px;position:absolute;font-weight:400;font-size: 45px;font-family: 'Lobster', cursive;color:#343A40;">Log In Form</h2>
	
	
	
	
	<div class="m" style="    margin-top: 179px;
    margin-left: -162px;">
	 <div class="form-group f"style="width: 400px;margin-left: 678px;
    position: absolute;
    margin-top: 257px;
    ">
    
    <input type="text" class="form-control"  placeholder="User Name" name ="username">
  </div>
   
  <div class="form-group i"style="width: 400px;
     margin-left: 678px;
    position: absolute;
    margin-top: 315px;">
    <input type="password" class="form-control"  placeholder="Password" name ="password">
  </div>
  <div class="form-group form-check j" style="width: 400px;
    margin-left: 679px;
    position: absolute;
    margin-top: 377px;">
    <input type="checkbox" class="form-check-input">
    <label class="form-check-label" for="exampleCheck1">Check me out</label>
  </div>
 
 <button type="submit" class="btn btn-dark" name="submit" style="    margin-left: 837px;
    position: absolute;
    margin-top: 428px;">Submit</button>
	
	
	
  </div>


</div>

</div>

</form>

 <?php

		  include "conn.php";
		   
		   if(isset($_POST['submit']))
		     {   
	            
		       	 $user = $_POST['username'];
                 $pass= $_POST['password'];
				 
			   
                   $sql = "SELECT * FROM dept_admin WHERE username = '$user' AND pass = '$pass'";
                	$records = $con->query($sql);
                    $User = "";
					$Password= "";
					$Dept = "";
					while($rows = $records->fetch_assoc())
					{
						$User = $rows['username'];
						$Password = $rows['pass'];
						$Dept = $rows['dept'];
					}
			  		if($User == $user && $pass==$Password && ($User!="" && $Password!=""))
					{
					
					  echo "Successfully log in";
					 $_SESSION['username'] = $user;
					 $_SESSION['password'] = $Password;
					 $_SESSION['dept'] = $Dept;
					 
					  header ("Location: approve.php");
					}	
                   else
                   echo "Error Email or password <br>";					   
              } 
			  
	 ?>
			


<a href="#" style="text-decoration:none;"><h2 style="position: absolute;
    margin-top: -137px;
    margin-left: 382px;font-weight:400;font-size: 45px;font-family: 'Lobster', cursive;color:#343A40;">Now,U Can Access The Website....</h2></a>
	
	
</div>
</div>
</div>
</div>

		

<script type="text/javascript" src="js/jquery.js"></script>
	
<script type="text/javascript" src="js/bootstrap.js"></script>
</body>
 </html>