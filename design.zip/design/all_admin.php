<?php
 session_start();
?>

<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>Member</title>
	<link href="https://fonts.googleapis.com/css?family=Oswald" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css" media="all" />
	<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
</head>
<body>
	
	
	
	<div class="header bg-light" style="height: 128px;">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
				<div class="col-md-2 logo">
						<img src="image/logo.png" alt="university logo" />
					</div>
					<div class="col-md-2"></div>
					<div class="col-md-8 u-text">
						<h1>Education is the Backbone of a Nation</h1>
					</div>
					
					<nav class="navbar navbar-light bg-dark bg-lg">
						  <form class="form-inline ">
							<input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search" style="margin-left: 1010px;">
							<button class="btn btn-outline-light my-2 my-sm-0" type="submit">Search</button>
							
						  </form>
						  <h3 style="margin-top: -40px; font-family: 'Oswald', sans-serif;font-weight:400;margin-left: 480px;color: #fff;">Library Management System,PUST</h3>
					</nav>
<img src="image/g3.jpg" alt="background" style="    width: 1344px;
    margin-left: -115px;
    height: 500px;
    opacity: 0.7;" />
					
					<h2 style="            margin-top: -468px;
    margin-left: 403px;position:absolute;font-weight:400;font-size: 45px;font-family: 'Lobster', cursive;color:#343A40;">Admin List</h2>
					
		<table border='1px' align='center'>
		<tbody style="    position: absolute;
    margin-top: -374px;
    margin-left: -242px; background:#transparent;">
					<tr>
						<th>Name</th>
						<th>Username</th>
						<th>Password</th>
						<th>Dept</th>
						<th>Contact</th> 
						<!--<th>Delete</th> -->
						
					</tr>
					
<tr><td style="color:#fff;">
		<?php
		  
		  include "conn.php";
		   
                   $sql = "SELECT * FROM dept_admin";
				   
                	$records = $con->query($sql);
				 
					while($rows = $records->fetch_assoc())
                         {  
					       // $code = $rows['name'];
							  echo "<tr>"; 
							   echo "<td style='color:#fff;'>" . $rows['name'] . "</td>";
							   echo "<td style='color:#fff;'>" . $rows['username'] . "</td>";
							    echo "<td style='color:#fff;'>" . $rows['pass'] . "</td>";
								  echo "<td style='color:#fff;'>" . $rows['dept'] . "</td>";
							    echo "<td style='color:#fff;'>" . $rows['phone'] . "</td>";  
							//	echo "<td>". "<a href='borrow.php?code=$code & usr=$user'>Borrow</a>" ."</td>";
							  echo "</tr>";
						  }				
?>
</td>
</tr>
		
		</tbody>
	    </table>
 </body>
 
</html>