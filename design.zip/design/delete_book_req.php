<?php
session_start()

?>

<?php
    
	 include "conn.php";
	 
       $code = $_GET['code'];
	   $username = $_GET['usr'];
	 
               $sql ="DELETE FROM borrow WHERE user ='$username' AND code = '$code'";
				   
                	$records = $con->query($sql);
					 if($records){
					echo "Successfully done</br>";
					 header("Location: return_book_request.php");
					 }
				else
				  echo "Something error";
				  

?>