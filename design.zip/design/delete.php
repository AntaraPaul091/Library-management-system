<?php
    
	 include "conn.php";
	 
      $user = $_GET['id'];
	  
	 
                   $sql = "DELETE FROM user  WHERE username ='$user'";
                   $records = $con->query($sql);
					if($records)
                    echo "SUCCESSFULLY DELET";
                   else
                   echo "SOMETHING IS ERROR";					   
	  

?>