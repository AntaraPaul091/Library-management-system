

<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>Log In Form</title>
	<link href="https://fonts.googleapis.com/css?family=Oswald" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css" media="all" />
	<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
</head>
<body>
	
	
	
	<div class="header bg-light" style="height: 128px;">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="col-md-2 logo">
						<img src="image/logo.png" alt="university logo" />
					</div>
					<div class="col-md-2"></div>
					<div class="col-md-8 u-text">
						<h1>Education is the Backbone of a Nation</h1>
					</div>
					
					<nav class="navbar navbar-light bg-dark bg-lg" style="height: 57px;">
						  
						  <h3 style="margin-top: -1px; font-family: 'Oswald', sans-serif;font-weight:400;margin-left: 480px;color: #fff;">Library Management System,PUST</h3>
					</nav>
					
	
		<form method = "post" action="">
	
	<div class="alll" style="background:#F8F9FA;    margin-top: -179px;
    width: 1343px;
    margin-left: -116px;height:735px;">
	
	<h2 style="        margin-top: 154px;
    margin-left: 613px;position:absolute;font-weight:400;font-size: 45px;font-family: 'Lobster', cursive;color:#343A40;">Log In Form</h2>
	
	
	
	
	<div class="m" style="    margin-top: 179px;
    margin-left: -162px;">
	 <div class="form-group f"style="width: 400px;margin-left: 678px;
    position: absolute;
    margin-top: 257px;
    ">
    
    <input type="text" class="form-control"  placeholder="User Name" name = "susername">
  </div>
   
  <div class="form-group i"style="width: 400px;
     margin-left: 678px;
    position: absolute;
    margin-top: 315px;">
    <input type="password" class="form-control"  placeholder="Password" name = "spassword">
  </div>
  <div class="form-group form-check j" style="width: 400px;
    margin-left: 679px;
    position: absolute;
    margin-top: 377px;">
    <input type="checkbox" class="form-check-input">
    <label class="form-check-label" for="exampleCheck1">Check me out</label>
  </div>
 
 <a href="pp.php"><button type="submit" class="btn btn-dark" name="submit" style="    margin-left: 837px;
    position: absolute;
    margin-top: 428px;">Submit</button></a>
	
	
	
  </div>
</form>


<?php

		  include "conn.php";
		   
		   if(isset($_POST['submit']))
		     {   
	            
		       	 $user = $_POST['susername'];
                 $pass= $_POST['spassword'];
				 
                   $sql = "SELECT * FROM supar_admin WHERE username = '$user' AND pass = '$pass'";
                	$records = $con->query($sql);
                    $User = "";
					$Password= "";
				 
					while($rows = $records->fetch_assoc())
					{
						$User = $rows['username'];
						$Password = $rows['pass'];
						 
					}
			  		if($User == $user && $pass==$Password && ($User!="" && $Password!=""))
					{
					
					  echo "Successfully log in";
					 $_SESSION['susername'] = $user;
					 $_SESSION['spassword'] = $Password;
					 
					  header ("Location: dashboard.php");
					}	
                   else
                   echo "Error Email or password <br>";					   
              } 
			  
	 ?>
			


</div>


</div>


	
	
</div>
</div>
</div>
</div>


<script type="text/javascript" src="js/jquery.js"></script>
	
<script type="text/javascript" src="js/bootstrap.js"></script>
</body>
 </html>