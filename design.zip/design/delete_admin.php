<?php
 include "conn.php";
echo "DELET";

?>