	
	<?php
	
	?>
	<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>Library Management System,PUST</title>
	<link href="https://fonts.googleapis.com/css?family=Lobster|Teko:300,400" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Oswald" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/lightbox.css" media="all" />
	<link rel="stylesheet" type="text/css" href="fontawesome/css/all.css" media="all" />
	<link rel="stylesheet" type="text/css" href="css/owl.carousel.css" media="all" />
	<link rel="stylesheet" type="text/css" href="css/owl.theme.default.css" media="all" />
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css" media="all" />
	<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
</head>
<body>
	
	
	
	
	
				
				<div class="footer">
					<h4>All Rights Reserved By SUBIR SAHA<br>For Contact:ss.buet@gmail.com<br>Mobile No:+8801717964747</h4>
				
				</div>
				
				










	<script type="text/javascript" src="js/jquery.js"></script>
	
	
	<script type="text/javascript" src="js/lightbox.js"></script>
	<script type="text/javascript" src="js/owl.carousel.js"></script>
	<script type="text/javascript" src="js/popper.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
</body>
</html>