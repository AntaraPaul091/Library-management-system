<?php
session_start()

?>

<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>Member</title>
	<link href="https://fonts.googleapis.com/css?family=Oswald" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css" media="all" />
	<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
</head>
<body>
	
	
	
	<div class="header bg-light" style="height: 128px;">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
				<div class="col-md-2 logo">
						<img src="image/logo.png" alt="university logo" />
					</div>
					<div class="col-md-2"></div>
					<div class="col-md-8 u-text">
						<h1>Education is the Backbone of a Nation</h1>
					</div>
					<nav class="navbar navbar-light bg-dark bg-lg" style="height: 53px;">
						 
						  <h3 style="margin-top: -5px; font-family: 'Oswald', sans-serif;font-weight:400;margin-left: 480px;color: #fff;">Library Management System,PUST</h3>
					</nav>
					 
                    <br><br>

<table border='1px' align='center'>
			<tr>
				<th>Book Name</th>
				<th>Author</th>
				<th>Return</th>
			</tr>
<?php
      
	  include "conn.php";
		   
	  $user = $_SESSION['username'] ;
	  $Password = $_SESSION['password'];
	
	 
                   $sql = "SELECT * FROM borrow,subject WHERE borrow.user = '$user' AND borrow.code =subject.code AND borrow.status = 1";
				   
                	$records = $con->query($sql);
					 $code = "";
					while($rows = $records->fetch_assoc())
                         {  
					        $code = $rows['code'];
							  echo "<tr>"; 
							  echo "<td>" . $rows['name'] . "</td>";
							    echo "<td>" . $rows['author'] . "</td>";
								echo "<td>". "<a href='return.php?code=$code & usr=$user'>Return</a>" ."</td>";
							  echo "</tr>";
						  }		
						

?>

</table>
</body>

</html>