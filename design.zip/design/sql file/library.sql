-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 17, 2019 at 11:27 PM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 7.1.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library`
--

-- --------------------------------------------------------

--
-- Table structure for table `book_admin`
--

CREATE TABLE `book_admin` (
  `Name` varchar(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `pass` varchar(20) NOT NULL,
  `phone` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book_admin`
--

INSERT INTO `book_admin` (`Name`, `username`, `pass`, `phone`) VALUES
('Babul', 'abc', '123', '0193333333');

-- --------------------------------------------------------

--
-- Table structure for table `borrow`
--

CREATE TABLE `borrow` (
  `user` varchar(110) NOT NULL,
  `code` int(11) NOT NULL,
  `ret` int(11) NOT NULL,
  `req` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `borrow`
--

INSERT INTO `borrow` (`user`, `code`, `ret`, `req`, `status`) VALUES
('asma', 3, 0, 1, 1),
('asma', 4, 0, 1, 1),
('asma', 5, 0, 1, 0),
('asma', 6, 0, 1, 0),
('asma', 8, 0, 1, 0),
('asma', 8, 0, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `dept_admin`
--

CREATE TABLE `dept_admin` (
  `name` varchar(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `pass` varchar(20) NOT NULL,
  `dept` varchar(10) NOT NULL,
  `phone` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dept_admin`
--

INSERT INTO `dept_admin` (`name`, `username`, `pass`, `dept`, `phone`) VALUES
('', '', '', '', ''),
('', '', '', '', ''),
('', '', '', '', ''),
('Jamal', 'cse', 'cse', 'cse', '01999999909'),
('kalam', 'eee', 'eee', 'eee', '0193333333'),
('khusi', 'ete', 'ete', 'ete', '0177777778'),
('helal', 'ice', 'ice', 'ice', '0177777777'),
('Jisan', 'math', 'math', 'math', '0187777777'),
('jesia', 'chemestry', 'chemestry', 'chemestry', '0177777777'),
('Rakib', 'physics', 'physics', 'physics', '01999999909'),
('hamid', 'bangla', 'bangla', 'bangla', '0177777777'),
('Mithun', 'english', 'english', 'english', '01999999923');

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `author` varchar(20) NOT NULL,
  `code` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`id`, `name`, `author`, `code`) VALUES
(2, 'C++', 'Harbard Shield', 2),
(3, 'Java', 'Ahsik', 3),
(4, 'Database', 'sami', 4),
(5, 'Numerical Methdoe', 'Niyaj Murshed', 5),
(6, 'data communication', 'Anotora', 6),
(8, 'ANSI C', 'balagurusami', 8);

-- --------------------------------------------------------

--
-- Table structure for table `supar_admin`
--

CREATE TABLE `supar_admin` (
  `name` varchar(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `pass` varchar(20) NOT NULL,
  `phone` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `supar_admin`
--

INSERT INTO `supar_admin` (`name`, `username`, `pass`, `phone`) VALUES
('supar admin', 'supar', 'admin', '0193333333');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `Fname` varchar(20) NOT NULL,
  `Lname` varchar(30) NOT NULL,
  `semister` varchar(20) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `pass` varchar(20) NOT NULL,
  `dept` varchar(20) NOT NULL,
  `session` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `member` int(11) NOT NULL,
  `status_2` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`Fname`, `Lname`, `semister`, `contact`, `username`, `pass`, `dept`, `session`, `email`, `member`, `status_2`) VALUES
('mina', 'khatun', '3-1', '01877777999', 'mina', '123', 'ce', '2015-2016', 'mina@gmail.com', 1, 0),
('Asma', 'khatun', '1-1', '017222222222', 'asma', '123', 'cse', '207-2018', 'asma@gmail.com', 1, 0);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
