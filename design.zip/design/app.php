<?php
session_start()
?>

<?php
    
	 include "conn.php";
	 
      $user = $_GET['id'];
	
	 
                   $sql = "UPDATE user SET member = 1 WHERE username ='$user' ";
                	$records = $con->query($sql);
					
					 if($records)
					echo "Successfuly Approve</br>";
				else
				  echo "Something error";
				  

?>