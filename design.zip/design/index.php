<?php

  include "conn.php";
  
  if(isset($_POST['submit']))
		     {   
	            
		       	 $user = $_POST['susername'];
                 $pass= $_POST['spassword'];
				 
                   $sql = "SELECT * FROM supar_admin WHERE username = '$user' AND pass = '$pass'";
                	$records = $con->query($sql);
                    $User = "";
					$Password= "";
				 
					while($rows = $records->fetch_assoc())
					{
						$User = $rows['username'];
						$Password = $rows['pass'];
						 
					}
			  		if($User == $user && $pass==$Password && ($User!="" && $Password!=""))
					{
					
					  echo "Successfully log in";
					 $_SESSION['susername'] = $user;
					 $_SESSION['spassword'] = $Password;
					 
					  header ("Location: dashboard.php");
					}	
                   else
                   echo "Error Email or password <br>";					   
              } 
?>



<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>Library Management System,PUST</title>
	<link href="https://fonts.googleapis.com/css?family=Lobster|Teko:300,400" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Oswald" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/lightbox.css" media="all" />
	<link rel="stylesheet" type="text/css" href="fontawesome/css/all.css" media="all" />
	<link rel="stylesheet" type="text/css" href="css/owl.carousel.css" media="all" />
	<link rel="stylesheet" type="text/css" href="css/owl.theme.default.css" media="all" />
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css" media="all" />
	<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
</head>
<body>
	<div class="header bg-light" style="height: 128px;">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="col-md-2 logo">
						<img src="image/logo.png" alt="university logo" />
					</div>
					<div class="col-md-2"></div>
					<div class="col-md-8 u-text">
						<h1>Education is the Backbone of a Nation</h1>
					</div>
					
					<nav class="navbar navbar-light bg-dark bg-lg">
						  <form class="form-inline ">
							<div class="dropdown">
						
								<button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="    margin-left: 1194px;"> Log In As
								</button>
								 
								 <div class="dropdown-menu" aria-labelledby="dropdownMenuButton" style="    margin-left: 1116px;">
									<a class="dropdown-item " href="super_login.php">Super Admin</a>
									<a class="dropdown-item " href="admin_login.php">Deptartment Admin</a>
									<a class="dropdown-item " href="book_admin_login.php"> Book Admin</a>
									<a class="dropdown-item " href="user_login.php">User</a>
                                </div>
                           </div>
						
						
						
						  </form>
						  <h3 style="margin-top: -40px; font-family: 'Oswald', sans-serif;font-weight:400;margin-left: 480px;color: #fff;">Library Management System,PUST</h3>
						  
						  
						  

					</nav>
					
					
					
					
					<div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
						  <div class="carousel-inner">
							<div class="carousel-item ">
							  <img src="image/c1.jpg" class="d-block w-100" alt="...">
							</div>
							<div class="carousel-item">
							  <img src="image/c2.jpg" class="d-block w-100" alt="...">
							  
							</div>
							<div class="carousel-item active">
							  <img src="image/c3.jpg" class="d-block w-100" alt="...">
							</div>
							<div class="carousel-item ">
							  <img src="image/c4.jpg" class="d-block w-100" alt="...">
							</div>
							
						  </div>
						  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
							<span class="carousel-control-prev-icon" aria-hidden="true"></span>
							<span class="sr-only">Previous</span>
						  </a>
						  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
							<span class="carousel-control-next-icon" aria-hidden="true"></span>
							<span class="sr-only">Next</span>
						  </a>
			 </div>
				
				
				<div class="mainmenu">
				
				<a href="#" title="Picture Gallery of PUST Library" style="text-decoration:none;"><h3 style="font-family: 'Oswald', sans-serif;
	font-weight:400;color:#000;font-size: 53px; text-align: center; margin-top: 44px;">Our Gallery</h3></a>

					<ul>
					 <li> <a href="image/g1.jpg" data-lightbox="images-1" data-title="Library"><img src="image/g1.jpg" alt="" style="   margin-top: 45px; height: 208px;border: 0px solid #ccc;box-shadow: 1px 1px 1px 1px #ccc; width: 377px; margin-left: -97px;"/></a><li>
						
						<li><a href="image/g2.jpg" data-lightbox="images-1" data-title="Bookstores of the library"><img src="image/g2.jpg" alt="" style="margin-top: -235px;height: 208px;border: 0px solid #ccc; box-shadow: 1px 1px 1px 1px #ccc;width:377px;margin-left: 330px;"/></a><li>
						
						<li><a href="image/g3.jpg" data-lightbox="images-1" data-title="Bookstores of the library"><img src="image/g3.jpg" alt="" style="height: 208px;    margin-left: 761px;
						margin-top: -281px;width: 377px;border: 0px solid #ccc; box-shadow: 1px 1px 1px 1px #ccc;" /></a><li>
						
						<li><a href="image/g4.jpg" data-lightbox="images-1" data-title="A student is searching for a book"><img src="image/g4.jpg" alt="" style="height: 208px;
						margin-left: -97px;box-shadow: 1px 1px 1px 1px #ccc;
						margin-top: -18px;border: 0px solid #ccc;
						width: 377px;" /></a><li>
						
						<li><a href="image/g5.jpg" data-lightbox="images-1" data-title="Students are reading in the library"><img src="image/g5.jpg" alt="" style="height: 208px;margin-left: 330px;margin-top: -231px;width: 377px;;box-shadow: 1px 1px 1px 1px #ccc;border: 0px solid #ccc;" /></a><li>
						
						<li><a href="image/g6.jpg" data-lightbox="images-1" data-title="CheckOut Box"><img src="image/g6.jpg" alt="" style="height: 208px;
						margin-left: 761px;
						margin-top: -285px;
						width: 377px;border: 0px solid #ccc;box-shadow: 1px 1px 1px 1px #ccc;" /></a><li>
						
					</ul>
             </div>
				
				<div class="footer1">
					<a href="#" title="Welcome to Our Library"><img src="image/welcome.jpg" alt="welcome image" style="height: 202px;width: 202px;border-radius: 50%; margin-left: 447px; margin-top: 11px; border: 1px solid gainsboro;"/></a>

					<h2 style="text-align: center;
    margin-top: 29px;font-weight:400;font-size: 45px;font-family: 'Lobster', cursive;color:#343A40;">Want To Be A Member of Our Library!</h2>
					
					<a href="registration.php" style="text-decoration:none;"><h2 style="text-align: center;
    margin-top: 29px;font-weight:400;font-size: 45px;font-family: 'Lobster', cursive;color:#343A40;">Registration Here....</h2></a>
				</div>
				
				<div class="footer">
					<h4>All Rights Reserved By SUBIR SAHA<br>For Contact:ss.buet@gmail.com<br>Mobile No:+8801717964747</h4>
				
				</div>
				
				</div>
			</div>
		</div>
	</div>




	<script type="text/javascript" src="js/jquery.js"></script>
	
	
	<script type="text/javascript" src="js/lightbox.js"></script>
	<script type="text/javascript" src="js/owl.carousel.js"></script>
	<script type="text/javascript" src="js/popper.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
</body>
</html>