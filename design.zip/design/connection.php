<?php
if(isset($post["submit"]))
{
		$link=mysqli_connect("localhost","root","");
	mysqli_select_db($link,"library");
	echo"connected";
	
}


?>