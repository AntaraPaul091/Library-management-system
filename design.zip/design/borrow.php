<?php
session_start();
?>
 
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>Book Admin</title>
	<link href="https://fonts.googleapis.com/css?family=Oswald" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css" media="all" />
	<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
	<link href="style.css" rel="stylesheet" type="text/css"/>
</head>
<body>
	
	
	<div class="header bg-light" style="height: 128px;">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
				<div class="col-md-2 logo">
						<img src="image/logo.png" alt="university logo" />
					</div>
					<div class="col-md-2"></div>
					<div class="col-md-8 u-text">
						<h1>Education is the Backbone of a Nation</h1>
					</div>
					
				<!-- <nav class="navbar navbar-light bg-dark bg-lg">
						  <form class="form-inline ">
							<input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search" style="margin-left: 1010px;">
							<button class="btn btn-outline-light my-2 my-sm-0" type="submit">Search</button>
							
						  </form>
						  <h3 style="margin-top: -40px; font-family: 'Oswald', sans-serif;font-weight:400;margin-left: 480px;color: #fff;">Library Management System,PUST</h3>
					</nav> -->
					
					<form name="form1" action="" method="post">
					<input type="text" name="t1" class ="form-control" placeholder="Enter books name" style="margin-top: 39px;" />
					<input type="submit" value="Search books" class="btn btn-default" style="color:#fff;background:#343A40;"/>
					</form> 

 

<?php
    
	 include "conn.php";
	 
	  $code = $_GET['code'];
	  $usernam = $_GET['usr'];
	  
                $sql ="INSERT INTO borrow(user, code, ret,req,status) VALUES ('$usernam','$code',0,1,0)";
                	$records = $con->query($sql);
					
					 if($records)
					echo "Request Pending</br>";
				else
				  echo "Something error";	  

?>

</body>
</html>