<?php
session_start()
?>

 
<?php
       
	 include "conn.php";
	 
       $code = $_GET['code'];
	   $username = $_GET['usr'];
	 
               $sql ="UPDATE borrow SET ret = 1 WHERE user ='$username' AND code = '$code'";
				   
                	$records = $con->query($sql);
					 if($records)
					echo "Request Pending</br>";
				else
				  echo "Something error";
						

?>
