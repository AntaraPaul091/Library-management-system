
<?php
session_start();
?>
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>Member Edit</title>
	<link href="https://fonts.googleapis.com/css?family=Oswald" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css" media="all" />
	<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
</head>
<body>
	
	
	
	<div class="header bg-light" style="height: 128px;">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="col-md-2 logo">
						<img src="image/logo.png" alt="university logo" />
					</div>
					<div class="col-md-2"></div>
					<div class="col-md-8 u-text">
						<h1>Education is the Backbone of a Nation</h1>
					</div>
					
					<nav class="navbar navbar-light bg-dark bg-lg">
						  <form class="form-inline ">
							<input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search" style="margin-left: 1010px;">
							<button class="btn btn-outline-light my-2 my-sm-0" type="submit">Search</button>
							
						  </form>
						  <h3 style="margin-top: -40px; font-family: 'Oswald', sans-serif;font-weight:400;margin-left: 480px;color: #fff;">Library Management System,PUST</h3>
					</nav>
					
				 <?php
     
	           include "conn.php";
	 
                $USER = $_GET['user'];
	 
                   $sql = "Select * From user WHERE username = '$USER' ";
                	$records = $con->query($sql);
				 
					while($rows = $records->fetch_assoc())
                         {   
					         $fname = $rows['Fname'];
							 $lname = $rows['Lname'];
							  $semister = $rows['semister'];
							 $dept = $rows['dept'];
							  $username = $rows['username'];
							 $session = $rows['session'];
							  $pass = $rows['pass'];
							 $contact = $rows['contact'];
							  $email = $rows['email'];
						 }	
                   					 
				  

?>				
	
		<form action="" method="post">
	
	<div class="all" style="background:#F8F9FA;    margin-top: -55px;
    width: 1343px;
    margin-left: -116px;height:1002px;">
	
	<h2 style="    margin-top: 82px;
    margin-left: 724px;position:absolute;font-weight:400;font-size: 45px;font-family: 'Lobster', cursive;color:#343A40;">Registration Form</h2>
	<a href="#" title="Registration Form is Beside.Fill It." style="text decoration:none;"><img src="image/registration-logo-png-6.png" alt=""style="height: 206px;
    margin-left: 127px;
    margin-top: 133px;
    position: absolute;" /></a>
	
	
	
	<div class="form-group a">
    <input type="text" class="form-control"  value="<?=(isset($fname))? $fname:'';?>" name="fname">
  </div>
  
  <div class="form-group b" style="width: 400px;
    margin-left: 678px;
    position: absolute;
    margin-top: 216px;">
    
    <input type="text" class="form-control" value="<?=(isset($lname))? $lname:'';?>" name="lname">
  </div>
  
  
   <div class="form-group c" style="width: 400px;
        margin-left: 678px;
    position: absolute;
    margin-top: 270px;">
    
    <input type="text" class="form-control" value="<?=(isset($semister))? $semister:'';?>" name="semister">
    
  </div>
   <div class="form-group d"style="width: 400px;
    margin-left: 678px;
    position: absolute;
    margin-top: 324px;">
   
    <input type="text" class="form-control" value="<?=(isset($session))? $session:'';?>" name="session">
    
  </div>
   <div class="form-group e" style="width: 400px;margin-left: 678px;
    position: absolute;
    margin-top: 378px;
    ">
    
    <input type="text" class="form-control" value="<?=(isset($dept))? $dept:'';?>" name="dept">
    
  </div>
  <div class="form-group f"style="width: 400px;margin-left: 678px;
    position: absolute;
    margin-top: 432px;
    ">
    
    <input type="text" class="form-control"  value="<?=(isset($username))? $username:'';?>" name="usr">
  </div>
  
  <div class="form-group g"style="width: 400px;
   margin-left: 678px;
    position: absolute;
    margin-top: 486px;">
    
    <input type="email" class="form-control" value="<?=(isset($email))? $email:'';?>" name="email" >
    
  </div>
  
   <div class="form-group h" style="width: 400px;
     margin-left: 678px;
    position: absolute;
    margin-top: 542px;">
   
    <input type="text" class="form-control"  value="<?=(isset($contact))? $contact:'';?>" name="contact">
  </div>
  
  <div class="form-group i"style="width: 400px;
     margin-left: 678px;
    position: absolute;
    margin-top: 596px;">
   
    <input type="password" class="form-control"  value="<?=(isset($pass))? $pass:'';?>" name="password">
  </div>
  <div class="form-group form-check j" style="width: 400px;
    margin-left: 679px;
    position: absolute;
    margin-top: 658px;">
    <input type="checkbox" class="form-check-input">
    <label class="form-check-label" for="exampleCheck1">Check me out</label>
  </div>
  <button type="submit" class="btn btn-dark" name="submit" style="    margin-left: 837px;
    position: absolute;
    margin-top: 705px;" >Submit</button>
  </div>
</form>

<?php
	       
	       include "conn.php";
		    
            if(isset($_POST['submit']))
			{      
		           
				$email = $_POST['email'];
				 $user = $_POST['usr'];
				  $fname = $_POST['fname'];
				   $lname = $_POST['lname'];
				    $semister = $_POST['semister'];
					 $session = $_POST['session'];
					  $dept = $_POST['dept'];
					   $contact = $_POST['contact'];
					    $password = $_POST['password'];
					   
					 
						$sql = "UPDATE user SET Fname='$fname',Lname='$lname',semister='$semister',contact='$contact',username='$user',pass='$password',dept='$dept',session='$session',email='$email' WHERE username = '$USER'";
						  $data = $con->query($sql);
						  
						  if($data)
						  {  
						   echo "Succesfully Update member information";
						  // header ("Location: member.php");
							  
						  }
						  else
							  echo "Fail";
				 
			}		
		        
	   ?>
	 
</div>

</div>
</div>
</div>


<script type="text/javascript" src="js/jquery.js"></script>
	
<script type="text/javascript" src="js/bootstrap.js"></script>
</body>
</html>