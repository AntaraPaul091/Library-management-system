<?php
session_start();
?>

<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>Book addded form</title>
	<link href="https://fonts.googleapis.com/css?family=Oswald" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css" media="all" />
	<link rel="stylesheet" type="text/css" href="css/style.css" media="all" />
</head>
<body>
	
	<div class="header bg-light" style="height: 128px;">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
				<div class="col-md-2 logo">
						<img src="image/logo.png" alt="university logo" />
					</div>
					<div class="col-md-2"></div>
					<div class="col-md-8 u-text">
						<h1>Education is the Backbone of a Nation</h1>
					</div>
					
					<nav class="navbar navbar-light bg-dark bg-lg">
						  <form class="form-inline ">
							<input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search" style="margin-left: 1010px;">
							<button class="btn btn-outline-light my-2 my-sm-0" type="submit">Search</button>
							
						  </form>
						  <h3 style="margin-top: -40px; font-family: 'Oswald', sans-serif;font-weight:400;margin-left: 480px;color: #fff;">Library Management System,PUST</h3>
					</nav>
					
					<h2 style="            margin-top: 74px;
    margin-left: 403px;position:absolute;font-weight:400;font-size: 45px;font-family: 'Lobster', cursive;color:#343A40;">Books Information</h2>
					
					
				 <?php
      
	           include "conn.php";
	 
                $code = $_GET['code'];
	 
                   $sql = "DELETE FROM subject WHERE code = '$code'";
                	$records = $con->query($sql);
				    if($records)
					  {  
						   echo "Succesfully Delete book";
						   header ("Location: book_admin.php");
							  
					  }
						  else
							  echo "Fail";
                   					   

?>
					 
			
 
			 
					
		 
		<script type="text/javascript" src="js/jquery.js"></script>
	
<script type="text/javascript" src="js/bootstrap.js"></script>
</body>

</html>